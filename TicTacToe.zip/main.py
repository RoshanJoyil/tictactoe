from termcolor import colored

controllerX = True
controllerO = True
loop = True

board = {'7': ' ' , '8': ' ' , '9': ' ' ,
            '4': ' ' , '5': ' ' , '6': ' ' ,
            '1': ' ' , '2': ' ' , '3': ' ' }

def printBoard(board):
    print(board['7'] + '|' + board['8'] + '|' + board['9'])
    print('-+-+-')
    print(board['4'] + '|' + board['5'] + '|' + board['6'])
    print('-+-+-')
    print(board['1'] + '|' + board['2'] + '|' + board['3'])

def naughts():
  while True:
    print(colored("\033[1m\t\t\t\t\t\t[7, 8, 9]\n\t\t\t\t\t\t[4, 5, 6]\n\t\t\t\t\t\t[1, 2, 3]\033[1m", "green"))
    x = int(input("Pick a number to place your circle: "))
    if board[str(x)] == ' ':
        board[str(x)] = "O"
        printBoard(board)
        break
    else:
      print("That space is already taken try again")

def crosses():
  while True:
    print(colored("\033[1m\t\t\t\t\t\t[7, 8, 9]\n\t\t\t\t\t\t[4, 5, 6]\n\t\t\t\t\t\t[1, 2, 3]\033[1m ", "green"))
    x = int(input("Pick a number to place your cross: "))
    if board[str(x)] == ' ':
        board[str(x)] = "X"
        printBoard(board)
        break
    else:
      print("That space is already taken try again")

def check_win():
  global controllerX
  global controllerO
  
  if board['7'] == "X" and board['8'] == "X" and board['9'] == "X":
    controllerX = False
  if board['4'] == "X" and board['5'] == "X" and board['6'] == "X":
    controllerX = False
  if board['1'] == "X" and board['2'] == "X" and board['3'] == "X":
    controllerX = False
  if board['7'] == "X" and board['5'] == "X" and board['3'] == "X":
    controllerX = False
  if board['1'] == "X" and board['5'] == "X" and board['9'] == "X":
    controllerX = False
  if board['7'] == "X" and board['4'] == "X" and board['1'] == "X":
    controllerX = False
  if board['8'] == "X" and board['5'] == "X" and board['2'] == "X":
    controllerX = False
  if board['3'] == "X" and board['6'] == "X" and board['9'] == "X":
    controllerX = False

  if (board['7'] == "O" and board['8'] == "O" and board['9']) == "O":
    controllerO = False
  if (board['4'] == "O" and board['5'] == "O" and board['6']) == "O":
    controllerO = False
  if (board['1'] == "O" and board['2'] == "O" and board['3']) == "O":
    controllerO = False
  if (board['7'] == "O" and board['5'] == "O" and board['3']) == "O":
    controllerO = False
  if (board['1'] == "O" and board['5'] == "O" and board['9']) == "O":
    controllerO = False
  if (board['7'] == "O" and board['4'] == "O" and board['1']) == "O":
    controllerO = False
  if (board['8'] == "O" and board['5'] == "O" and board['2']) == "O":
    controllerO = False
  if (board['3'] == "O" and board['6'] == "O" and board['9']) == "O":
    controllerO = False


incr = 0

while loop == True:
  incr += 1
  if incr % 2 != 0:
    naughts()
    check_win()
    if controllerO == False:
      print("naughts won")
      loop = False
  else:
    crosses()
    check_win
    if controllerX == False:
      print("crosses won")
      loop = False